import { convexQuery, useConvexMutation } from "@convex-dev/react-query";
import { api } from "@ec/backend/api";
import { Button } from "@ec/ui/components/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@ec/ui/components/dialog";
import { Input } from "@ec/ui/components/input";
import { Item, ItemContent, ItemHeader, ItemTitle } from "@ec/ui/components/item";
import { useMutation, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useConvex, useQuery as useConvexQuery } from "convex/react";
import type { FunctionReturnType } from "convex/server";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";

const retentionRunsQuery = convexQuery(api.retention.listRecentRuns, {});

export const Route = createFileRoute("/_authenticated/admin/privacy")({
  component: AdminPrivacyPage,
  loader: async ({ context: { queryClient } }) => await queryClient.ensureQueryData(retentionRunsQuery),
});

type PrivacySubject = NonNullable<FunctionReturnType<typeof api.privacy.inspectSubject>>;
type Operation = "access" | "erasure" | "export" | "objection" | "rectification" | "suppressionRemoval" | "unsubscription";
type VerificationMethod = "additionalEvidence" | "emailChallenge";

const OPERATION_LABELS: Record<Operation, string> = {
  access: "Traiter la demande d’accès",
  erasure: "Effacer les données",
  export: "Exporter les données",
  objection: "Enregistrer une opposition",
  rectification: "Rectifier le prénom",
  suppressionRemoval: "Lever la suppression vérifiée",
  unsubscription: "Désinscrire de la newsletter",
};

const formatDate = (timestamp: number | null) =>
  timestamp === null
    ? "—"
    : new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeStyle: "short", timeZone: "UTC" }).format(timestamp);

function AdminPrivacyPage() {
  const convex = useConvex();
  const [emailInput, setEmailInput] = useState("");
  const [exporting, setExporting] = useState<"csv" | "json">();
  const [searchedEmail, setSearchedEmail] = useState<string>();
  const subject = useConvexQuery(api.privacy.inspectSubject, searchedEmail ? { email: searchedEmail } : "skip");
  const { data: retentionRuns } = useSuspenseQuery(retentionRunsQuery);

  const downloadPortabilityExport = async (format: "csv" | "json") => {
    setExporting(format);
    try {
      const result = await convex.query(api.newsletter.exportData, { format });
      const url = URL.createObjectURL(new Blob([result.content], { type: result.contentType }));
      const link = document.createElement("a");
      link.download = `newsletter-portability-${new Date().toISOString()}.${format}`;
      link.href = url;
      link.click();
      URL.revokeObjectURL(url);
      toast.success(`Export ${format.toUpperCase()} généré.`);
    } catch {
      toast.error("L’export global n’a pas pu être généré.");
    } finally {
      setExporting(undefined);
    }
  };

  return (
    <section className="flex flex-col gap-8">
      <header>
        <h1 className="text-foreground text-3xl font-extrabold">Demandes de confidentialité</h1>
        <p className="text-muted-foreground text-sm">Recherche exacte par adresse canonique. Aucune opération groupée n’est disponible.</p>
      </header>

      <PrivacySection title="Portabilité globale de la newsletter">
        <p className="text-muted-foreground mb-4 text-sm">
          Exporte l’état fournisseur-indépendant des personnes, consentements, éligibilités, accès e-book et suppressions. Aucun jeton actif
          ni journal technique court n’est inclus.
        </p>
        <div className="flex flex-wrap gap-3">
          <Button
            disabled={exporting !== undefined}
            type="button"
            onClick={() => {
              void downloadPortabilityExport("json");
            }}
          >
            {exporting === "json" ? "Génération…" : "Télécharger JSON"}
          </Button>
          <Button
            disabled={exporting !== undefined}
            type="button"
            variant="outline"
            onClick={() => {
              void downloadPortabilityExport("csv");
            }}
          >
            {exporting === "csv" ? "Génération…" : "Télécharger CSV"}
          </Button>
        </div>
      </PrivacySection>

      <PrivacySection title="Dernières exécutions de rétention">
        {retentionRuns.length === 0 && <p className="text-muted-foreground text-sm">Aucune exécution enregistrée.</p>}
        {retentionRuns.length > 0 && (
          <ul className="flex flex-col gap-2 text-sm">
            {retentionRuns.map((run) => (
              <li className="grid gap-1 rounded-xl border p-3 sm:grid-cols-4" key={run._id}>
                <span>{formatDate(run._creationTime)}</span>
                <span>
                  {run.status === "completed" && `Terminée ${formatDate(run.finishedAt)}`}
                  {run.status === "running" && "En cours"}
                  {run.status === "failed" && `Interrompue ${formatDate(run.failedAt)} · phase ${run.failurePhase}`}
                </span>
                <span>
                  Profils en attente : {run.anonymizedPendingProfiles} · anciens abonnés : {run.anonymizedFormerProfiles} · journaux :{" "}
                  {run.deletedTechnicalLogs} · téléchargements : {run.deletedDownloads}
                </span>
                <span className="text-muted-foreground break-all">Workflow : {run.workflowId ?? "—"}</span>
              </li>
            ))}
          </ul>
        )}
      </PrivacySection>

      <form
        className="bg-card flex flex-col gap-3 rounded-2xl border p-4 sm:flex-row sm:items-end"
        onSubmit={(event) => {
          event.preventDefault();
          setSearchedEmail(emailInput);
        }}
      >
        <label className="flex flex-1 flex-col gap-2 text-sm font-medium" htmlFor="privacy-email">
          Adresse e-mail de la personne vérifiée
          <Input
            required
            id="privacy-email"
            type="email"
            value={emailInput}
            onChange={(event) => {
              setEmailInput(event.target.value);
            }}
          />
        </label>
        <Button type="submit">Rechercher</Button>
      </form>

      {searchedEmail && subject === undefined && <p className="text-muted-foreground text-sm">Recherche en cours…</p>}
      {searchedEmail && subject === null && (
        <p className="text-muted-foreground rounded-2xl border p-4 text-sm">Aucune donnée connue pour cette adresse.</p>
      )}
      {searchedEmail && subject && <PrivacySubjectView key={searchedEmail} email={searchedEmail} subject={subject} />}
    </section>
  );
}

function PrivacySubjectView({ email, subject }: { email: string; subject: PrivacySubject }) {
  return (
    <div className="flex flex-col gap-6">
      <IdentitySection subject={subject} />
      <ConsentSection subject={subject} />
      <DeliverySection subject={subject} />
      <EbookSection subject={subject} />
      <AuditSection subject={subject} />
      <VerificationSection email={email} subject={subject} />
      <PrivacyOperations email={email} subject={subject} />
    </div>
  );
}

function IdentitySection({ subject }: { subject: PrivacySubject }) {
  return (
    <PrivacySection title="Identité">
      {subject.profile ? (
        <dl className="grid gap-3 sm:grid-cols-3">
          <Detail label="E-mail" value={subject.profile.email ?? "—"} />
          <Detail label="Prénom" value={subject.profile.firstName ?? "—"} />
          <Detail label="Rôle" value={subject.profile.role} />
        </dl>
      ) : (
        <p className="text-muted-foreground text-sm">Aucun profil identifiant conservé.</p>
      )}
    </PrivacySection>
  );
}

function ConsentSection({ subject }: { subject: PrivacySubject }) {
  return (
    <PrivacySection title="Consentement newsletter">
      {subject.newsletterConsent.periods.length === 0 ? (
        <p className="text-muted-foreground text-sm">Aucune période de consentement.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b">
                <th className="p-2">Demandé</th>
                <th className="p-2">Confirmé</th>
                <th className="p-2">Désinscrit</th>
              </tr>
            </thead>
            <tbody>
              {subject.newsletterConsent.periods.map((period) => (
                <tr className="border-b last:border-0" key={period._id}>
                  <td className="p-2">{formatDate(period.requestedAt)}</td>
                  <td className="p-2">{formatDate(period.confirmedAt)}</td>
                  <td className="p-2">{formatDate(period.unsubscribedAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </PrivacySection>
  );
}

function DeliverySection({ subject }: { subject: PrivacySubject }) {
  return (
    <PrivacySection title="Éligibilité de livraison et état de confidentialité">
      <dl className="grid gap-3 sm:grid-cols-3">
        <Detail label="Éligible" value={subject.deliveryEligibility.eligible ? "Oui" : "Non"} />
        <Detail label="État" value={subject.deliveryEligibility.status} />
        <Detail label="Suppression" value={subject.privacyState.suppressed ? "Active" : "Absente"} />
      </dl>
      {subject.deliveryEligibility.restriction && (
        <p className="mt-3 text-sm">
          Restriction : {subject.deliveryEligibility.restriction.reason} · origine {subject.deliveryEligibility.restriction.restrictedBy}
        </p>
      )}
    </PrivacySection>
  );
}

function EbookSection({ subject }: { subject: PrivacySubject }) {
  return (
    <PrivacySection title="Historique de l’e-book de bienvenue">
      {subject.welcomeEbookAccess.issuances.length === 0 ? (
        <p className="text-muted-foreground text-sm">Aucune délivrance conservée.</p>
      ) : (
        <ul className="flex flex-col gap-2 text-sm">
          {subject.welcomeEbookAccess.issuances.map((issuance) => (
            <li className="rounded-xl border p-3" key={issuance._id}>
              {formatDate(issuance._creationTime)} · {issuance.kind} · {issuance.ebook.title} (version {issuance.ebook.version})
            </li>
          ))}
        </ul>
      )}
    </PrivacySection>
  );
}

function AuditSection({ subject }: { subject: PrivacySubject }) {
  return (
    <PrivacySection title="Historique des opérations de confidentialité">
      {subject.privacyState.audits.length === 0 ? (
        <p className="text-muted-foreground text-sm">Aucune opération enregistrée.</p>
      ) : (
        <ul className="flex flex-col gap-2 text-sm">
          {subject.privacyState.audits.map((audit) => (
            <li className="grid gap-1 rounded-xl border p-3 sm:grid-cols-4" key={audit._id}>
              <span>{formatDate(audit._creationTime)}</span>
              <span>
                {audit.kind}
                {audit.kind === "verification" ? ` · ${audit.requestKind} · ${audit.method}` : ""}
              </span>
              <span>{audit.outcome}</span>
              <span className="text-muted-foreground break-all">Admin : {audit.performedBy}</span>
            </li>
          ))}
        </ul>
      )}
    </PrivacySection>
  );
}

function VerificationSection({ email, subject }: { email: string; subject: PrivacySubject }) {
  const [method, setMethod] = useState<VerificationMethod>("emailChallenge");
  const [requestKind, setRequestKind] = useState<Operation>("access");
  const [outcome, setOutcome] = useState<"completed" | "rejected">();
  const verification = useMutation({ mutationFn: useConvexMutation(api.privacy.recordVerification) });

  const confirm = async () => {
    if (outcome === undefined) return;
    try {
      await verification.mutateAsync({ email, method, outcome, requestKind });
      toast.success("Résultat de vérification enregistré.");
      setOutcome(undefined);
    } catch {
      toast.error("Le résultat de vérification n’a pas été enregistré.");
    }
  };

  return (
    <PrivacySection title="Vérification d’identité">
      <p className="text-muted-foreground mb-4 text-sm">
        Enregistrez uniquement la catégorie de méthode et son résultat, jamais les preuves.
      </p>
      {subject.privacyState.grants.length > 0 && (
        <ul className="mb-4 flex flex-col gap-1 text-sm">
          {subject.privacyState.grants.map((grant) => (
            <li key={grant.requestKind}>
              Permission {grant.requestKind} valable jusqu’au {formatDate(grant.expiresAt)}
            </li>
          ))}
        </ul>
      )}
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="flex flex-col gap-2 text-sm">
          Demande concernée
          <select
            className="h-9 rounded-md border bg-transparent px-3"
            value={requestKind}
            onChange={(event) => {
              setRequestKind(event.target.value as Operation);
            }}
          >
            {Object.entries(OPERATION_LABELS).map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-2 text-sm">
          Méthode
          <select
            className="h-9 rounded-md border bg-transparent px-3"
            value={method}
            onChange={(event) => {
              setMethod(event.target.value as VerificationMethod);
            }}
          >
            <option value="emailChallenge">Défi envoyé à l’adresse canonique</option>
            <option value="additionalEvidence">Preuve supplémentaire proportionnée</option>
          </select>
        </label>
      </div>
      <div className="mt-4 flex flex-wrap gap-3">
        <Button
          type="button"
          onClick={() => {
            setOutcome("completed");
          }}
        >
          Enregistrer comme vérifiée
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={() => {
            setOutcome("rejected");
          }}
        >
          Enregistrer comme non vérifiée
        </Button>
      </div>
      <Dialog
        open={outcome !== undefined}
        onOpenChange={(open) => {
          if (!open) setOutcome(undefined);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmer le résultat de vérification</DialogTitle>
            <DialogDescription>
              Enregistrer la demande {requestKind} pour {email} comme {outcome === "completed" ? "vérifiée" : "non vérifiée"}.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter showCloseButton>
            <Button
              disabled={verification.isPending}
              onClick={() => {
                void confirm();
              }}
            >
              {verification.isPending ? "Enregistrement…" : "Confirmer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PrivacySection>
  );
}

function PrivacyOperations({ email, subject }: { email: string; subject: PrivacySubject }) {
  const [operation, setOperation] = useState<Operation>();
  const [firstName, setFirstName] = useState(subject.profile?.firstName ?? "");
  const access = useMutation({ mutationFn: useConvexMutation(api.privacy.fulfillAccessRequest) });
  const erase = useMutation({ mutationFn: useConvexMutation(api.privacy.fulfillErasureRequest) });
  const exportData = useMutation({ mutationFn: useConvexMutation(api.privacy.fulfillExportRequest) });
  const object = useMutation({ mutationFn: useConvexMutation(api.privacy.fulfillObjectionRequest) });
  const rectify = useMutation({ mutationFn: useConvexMutation(api.privacy.fulfillRectificationRequest) });
  const removeSuppression = useMutation({ mutationFn: useConvexMutation(api.privacy.fulfillSuppressionRemovalRequest) });
  const unsubscribe = useMutation({ mutationFn: useConvexMutation(api.privacy.fulfillUnsubscriptionRequest) });
  const isPending = [access, erase, exportData, object, rectify, removeSuppression, unsubscribe].some(({ isPending: pending }) => pending);
  const isAuthorized = (requestKind: Operation) => subject.privacyState.grants.some((grant) => grant.requestKind === requestKind);

  const confirmOperation = async () => {
    if (!operation) return;
    try {
      const payload = { confirmed: true as const, email };
      let outcome: "completed" | "rejected";
      if (operation === "access") ({ outcome } = await access.mutateAsync(payload));
      else if (operation === "export") {
        const result = await exportData.mutateAsync(payload);
        ({ outcome } = result);
        if (result.data) downloadJson(result.data, email);
      } else if (operation === "rectification") ({ outcome } = await rectify.mutateAsync({ ...payload, firstName }));
      else if (operation === "unsubscription") ({ outcome } = await unsubscribe.mutateAsync(payload));
      else if (operation === "objection") ({ outcome } = await object.mutateAsync(payload));
      else if (operation === "suppressionRemoval") ({ outcome } = await removeSuppression.mutateAsync(payload));
      else ({ outcome } = await erase.mutateAsync(payload));

      if (outcome === "completed") toast.success("Opération enregistrée.");
      else toast.error("L’opération a été rejetée.");
      setOperation(undefined);
    } catch {
      toast.error("L’opération a échoué. Aucun résultat n’a été confirmé.");
    }
  };

  return (
    <PrivacySection title="Opérations confirmées">
      <p className="text-muted-foreground mb-4 text-sm">
        Chaque opération exige une vérification correspondante, indépendante, confirmée et à usage unique.
      </p>
      <div className="grid gap-3 sm:grid-cols-2">
        <OperationButton
          disabled={!isAuthorized("access")}
          label={OPERATION_LABELS.access}
          onClick={() => {
            setOperation("access");
          }}
        />
        <OperationButton
          disabled={!isAuthorized("export")}
          label={OPERATION_LABELS.export}
          onClick={() => {
            setOperation("export");
          }}
        />
        <div className="flex gap-2">
          <Input
            aria-label="Nouveau prénom"
            value={firstName}
            onChange={(event) => {
              setFirstName(event.target.value);
            }}
          />
          <OperationButton
            disabled={!isAuthorized("rectification")}
            label={OPERATION_LABELS.rectification}
            onClick={() => {
              setOperation("rectification");
            }}
          />
        </div>
        <OperationButton
          disabled={!isAuthorized("unsubscription")}
          label={OPERATION_LABELS.unsubscription}
          onClick={() => {
            setOperation("unsubscription");
          }}
        />
        <OperationButton
          disabled={!isAuthorized("objection")}
          label={OPERATION_LABELS.objection}
          onClick={() => {
            setOperation("objection");
          }}
        />
        <OperationButton
          disabled={!isAuthorized("suppressionRemoval")}
          label={OPERATION_LABELS.suppressionRemoval}
          onClick={() => {
            setOperation("suppressionRemoval");
          }}
        />
        <OperationButton
          destructive
          disabled={!isAuthorized("erasure")}
          label={OPERATION_LABELS.erasure}
          onClick={() => {
            setOperation("erasure");
          }}
        />
      </div>

      <Dialog
        open={operation !== undefined}
        onOpenChange={(open) => {
          if (!open) setOperation(undefined);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmer l’opération</DialogTitle>
            <DialogDescription>
              {operation ? OPERATION_LABELS[operation] : "Opération"} pour {email}. Cette confirmation sera auditée.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter showCloseButton>
            <Button
              disabled={isPending}
              variant={operation === "erasure" ? "destructive" : "default"}
              onClick={() => {
                void confirmOperation();
              }}
            >
              {isPending ? "Traitement…" : "Confirmer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PrivacySection>
  );
}

function PrivacySection({ children, title }: { children: ReactNode; title: string }) {
  return (
    <Item variant="outline">
      <ItemHeader>
        <ItemTitle>{title}</ItemTitle>
      </ItemHeader>
      <ItemContent className="basis-full">{children}</ItemContent>
    </Item>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-muted-foreground text-xs font-medium tracking-wide uppercase">{label}</dt>
      <dd className="mt-1 text-sm break-all">{value}</dd>
    </div>
  );
}

function OperationButton({
  destructive = false,
  disabled = false,
  label,
  onClick,
}: {
  destructive?: boolean;
  disabled?: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <Button disabled={disabled} type="button" variant={destructive ? "destructive" : "outline"} onClick={onClick}>
      {label}
    </Button>
  );
}

function downloadJson(data: unknown, email: string) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
  const link = document.createElement("a");
  link.download = `donnees-${email}.json`;
  link.href = url;
  link.click();
  URL.revokeObjectURL(url);
}
